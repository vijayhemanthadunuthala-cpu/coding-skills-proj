// ── State ──────────────────────────────────────────────
const state = {
  stops: [],          // [{x,y,label}]
  greedyRoute: null,
  dpRoute: null,
  animFrame: null,
};

const canvas  = document.getElementById("map-canvas");
const ctx     = canvas.getContext("2d");
const PAD     = 50;

// ── Canvas resize ──────────────────────────────────────
function resize() {
  canvas.width  = canvas.offsetWidth;
  canvas.height = canvas.offsetHeight;
  draw();
}
window.addEventListener("resize", resize);
setTimeout(resize, 50);

// ── Click to add stop ──────────────────────────────────
canvas.addEventListener("click", (e) => {
  const rect = canvas.getBoundingClientRect();
  const x = ((e.clientX - rect.left) / rect.width)  * 100;
  const y = ((e.clientY - rect.top)  / rect.height) * 100;
  state.stops.push({ x: +x.toFixed(2), y: +y.toFixed(2), label: `S${state.stops.length}` });
  clearRoutes();
  updateStopList();
  draw();
});

// ── Preset stops ───────────────────────────────────────
const PRESETS = {
  6: [
    {x:20,y:30},{x:50,y:15},{x:75,y:35},
    {x:65,y:65},{x:35,y:70},{x:15,y:55}
  ],
  10: [
    {x:10,y:20},{x:30,y:10},{x:55,y:18},{x:75,y:25},{x:85,y:50},
    {x:70,y:72},{x:45,y:80},{x:25,y:75},{x:12,y:55},{x:20,y:40}
  ],
  15: [
    {x:10,y:15},{x:28,y:8 },{x:48,y:12},{x:65,y:8 },{x:80,y:20},
    {x:88,y:38},{x:82,y:58},{x:68,y:72},{x:50,y:80},{x:32,y:78},
    {x:15,y:65},{x:8, y:45},{x:18,y:32},{x:38,y:35},{x:58,y:45}
  ]
};

function loadPreset(n) {
  state.stops = PRESETS[n].map((p, i) => ({ ...p, label: `S${i}` }));
  clearRoutes();
  updateStopList();
  draw();
}

function clearAll() {
  state.stops = [];
  clearRoutes();
  updateStopList();
  draw();
  document.getElementById("results-panel").classList.add("hidden");
}

function clearRoutes() {
  state.greedyRoute = null;
  state.dpRoute = null;
}

// ── Stop list UI ───────────────────────────────────────
function updateStopList() {
  const depot = +document.getElementById("depot-input").value || 0;
  const list  = document.getElementById("stop-list");
  list.innerHTML = state.stops.map((s, i) => `
    <div class="stop-item ${i === depot ? 'depot' : ''}">
      <span class="dot"></span>
      <span class="idx">#${i}</span>
      <span>${s.label} &nbsp;(${s.x.toFixed(1)}, ${s.y.toFixed(1)})</span>
      ${i === depot ? '<span style="margin-left:auto;font-size:0.7rem;color:var(--depot)">DEPOT</span>' : ''}
    </div>
  `).join("");
}

document.getElementById("depot-input").addEventListener("input", () => {
  updateStopList();
  draw();
});

// ── Coordinate mapping ─────────────────────────────────
function toCanvas(px, py) {
  return [
    PAD + (px / 100) * (canvas.width  - 2 * PAD),
    PAD + (py / 100) * (canvas.height - 2 * PAD),
  ];
}

// ── Draw ───────────────────────────────────────────────
function draw() {
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  // Grid dots
  ctx.fillStyle = "rgba(255,255,255,0.04)";
  for (let gx = PAD; gx < W - PAD; gx += 40)
    for (let gy = PAD; gy < H - PAD; gy += 40)
      fillCircle(gx, gy, 1.5);

  const depot = +document.getElementById("depot-input").value || 0;

  // Draw route lines
  if (state.greedyRoute) drawRoute(state.greedyRoute, "rgba(247,183,49,0.65)", 2.5);
  if (state.dpRoute)     drawRoute(state.dpRoute,     "rgba(38,222,129,0.65)", 2.5, [6,4]);

  // Draw stops
  state.stops.forEach((s, i) => {
    const [cx, cy] = toCanvas(s.x, s.y);
    const isDepot  = i === depot;
    const r = isDepot ? 14 : 10;

    // Glow
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r * 2);
    if (isDepot) {
      grad.addColorStop(0, "rgba(255,159,67,0.35)");
      grad.addColorStop(1, "rgba(255,159,67,0)");
    } else {
      grad.addColorStop(0, "rgba(162,155,254,0.3)");
      grad.addColorStop(1, "rgba(162,155,254,0)");
    }
    ctx.beginPath();
    ctx.arc(cx, cy, r * 2, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    // Circle
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fillStyle   = isDepot ? "#ff9f43" : "#a29bfe";
    ctx.strokeStyle = isDepot ? "#fff"    : "rgba(255,255,255,0.5)";
    ctx.lineWidth   = isDepot ? 2.5 : 1.5;
    ctx.fill();
    ctx.stroke();

    // Label
    ctx.font      = `bold ${isDepot ? 10 : 9}px 'JetBrains Mono'`;
    ctx.fillStyle = isDepot ? "#1a1200" : "#0d0f14";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(isDepot ? "🏠" : i, cx, cy);

    // Name above
    ctx.font      = "bold 10px 'Syne'";
    ctx.fillStyle = "rgba(255,255,255,0.6)";
    ctx.fillText(s.label, cx, cy - r - 7);
  });
}

function drawRoute(route, color, lineWidth, dash = []) {
  if (!route || route.length < 2) return;
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth   = lineWidth;
  ctx.setLineDash(dash);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  ctx.beginPath();
  for (let k = 0; k < route.length; k++) {
    const s = state.stops[route[k]];
    if (!s) continue;
    const [cx, cy] = toCanvas(s.x, s.y);
    if (k === 0) ctx.moveTo(cx, cy);
    else         ctx.lineTo(cx, cy);
  }
  ctx.stroke();

  // Arrows
  for (let k = 0; k < route.length - 1; k++) {
    const a = state.stops[route[k]];
    const b = state.stops[route[k + 1]];
    if (!a || !b) continue;
    const [ax, ay] = toCanvas(a.x, a.y);
    const [bx, by] = toCanvas(b.x, b.y);
    const mx = (ax + bx) / 2, my = (ay + by) / 2;
    const angle = Math.atan2(by - ay, bx - ax);
    drawArrow(mx, my, angle, color);
  }
  ctx.restore();
}

function drawArrow(x, y, angle, color) {
  const size = 7;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.beginPath();
  ctx.moveTo(size, 0);
  ctx.lineTo(-size, -size * 0.5);
  ctx.lineTo(-size,  size * 0.5);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.setLineDash([]);
  ctx.fill();
  ctx.restore();
}

function fillCircle(x, y, r) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

// ── API calls ──────────────────────────────────────────
async function runAlgorithm(type) {
  if (state.stops.length < 2) {
    showError("Add at least 2 stops first!");
    return;
  }
  const depot = +document.getElementById("depot-input").value || 0;
  if (depot >= state.stops.length) {
    showError("Depot index out of range!");
    return;
  }

  setLoading(true);

  try {
    const res = await fetch(`/api/${type}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ stops: state.stops, depot }),
    });
    const data = await res.json();

    if (data.error) { showError(data.error); setLoading(false); return; }

    if (type === "greedy") {
      state.greedyRoute = data.route;
      state.dpRoute = null;
      showSingleResult(data, "greedy");
    } else if (type === "dp") {
      state.dpRoute = data.route;
      state.greedyRoute = null;
      showSingleResult(data, "dp");
    } else {
      state.greedyRoute = data.greedy.route;
      state.dpRoute     = data.dp.route;
      showCompareResult(data);
    }
    draw();
  } catch (e) {
    showError("Server error: " + e.message);
  }
  setLoading(false);
}

function setLoading(on) {
  document.querySelectorAll(".btn").forEach(b => b.disabled = on);
  if (on) {
    const p = document.getElementById("results-panel");
    p.classList.remove("hidden");
    p.innerHTML = `<div><span class="spinner"></span> Computing route…</div>`;
  }
}

function showSingleResult(data, type) {
  const cls   = type === "greedy" ? "greedy-color" : "dp-color";
  const panel = document.getElementById("results-panel");
  panel.classList.remove("hidden");
  panel.innerHTML = `
    <h3 class="${cls}">${data.algorithm}</h3>
    <div class="result-block">
      <div class="result-label">Total Distance</div>
      <div class="result-value ${cls}">${data.total_distance} units</div>
    </div>
    <div class="result-block">
      <div class="result-label">Computation Time</div>
      <div class="result-value">${data.time_ms} ms</div>
    </div>
    <div class="result-block">
      <div class="result-label">Complexity</div>
      <div class="result-value">${data.complexity}</div>
    </div>
    <div class="result-block">
      <div class="result-label">Route Sequence</div>
      <div class="route-sequence">${data.route.join(" → ")}</div>
    </div>
  `;
}

function showCompareResult(data) {
  const g = data.greedy;
  const d = data.dp;
  const imp = data.improvement_percent;
  const dpError = d.error;

  const panel = document.getElementById("results-panel");
  panel.classList.remove("hidden");
  panel.innerHTML = `
    <h3>Comparison</h3>

    <div class="result-block">
      <div class="result-label greedy-color">● Greedy</div>
      <div class="result-value greedy-color">${g.total_distance} units</div>
      <div style="font-size:0.75rem;color:var(--muted);">${g.time_ms} ms &nbsp;|&nbsp; ${g.complexity}</div>
      <div class="route-sequence">${g.route.join(" → ")}</div>
    </div>

    <div class="result-block">
      <div class="result-label dp-color">● DP (Held-Karp)</div>
      ${dpError
        ? `<div class="error-box">${dpError}</div>`
        : `<div class="result-value dp-color">${d.total_distance} units</div>
           <div style="font-size:0.75rem;color:var(--muted);">${d.time_ms} ms &nbsp;|&nbsp; ${d.complexity}</div>
           <div class="route-sequence">${d.route.join(" → ")}</div>`
      }
    </div>

    ${imp !== null && imp !== undefined && !dpError ? `
    <div class="improvement-box">
      <div class="result-label">DP improvement over Greedy</div>
      <div class="result-value accent-color">${imp > 0 ? `${imp}% better` : imp === 0 ? "Same route!" : `Greedy was ${Math.abs(imp)}% better`}</div>
    </div>` : ""}
  `;
}

function showError(msg) {
  const panel = document.getElementById("results-panel");
  panel.classList.remove("hidden");
  panel.innerHTML = `<div class="error-box">⚠ ${msg}</div>`;
}

// ── Init ───────────────────────────────────────────────
loadPreset(6);
